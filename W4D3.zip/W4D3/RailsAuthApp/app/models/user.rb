class User < ActiveRecord::Base
  validates :username, presence: true, uniqueness: true
  validates :password,
  validates :session_token, presence: true

  before_validation :ensure_session_token
end
